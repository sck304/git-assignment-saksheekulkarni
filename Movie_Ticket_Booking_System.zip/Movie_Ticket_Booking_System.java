package Fullstack;

import java.util.*;

public class Movie_Ticket_Booking_System {

    String movie;
    String ticket_type;
    String seat_type;
    String day;
    String coupon;

    int no_of_tickets;
    int popcorn=0, coke=0, nachos=0;

    int booking_fee = 50;

    double ticket_price;
    double seat_charge;
    double subtotal;
    double food_total;
    double gst;
    double discount=0;
    double coupon_discount=0;
    double final_amount;

    Movie_Ticket_Booking_System(String movie,String ticket_type,String seat_type,
                                String day,int tickets,String coupon,
                                int popcorn,int coke,int nachos)
    {
        this.movie=movie;
        this.ticket_type=ticket_type;
        this.seat_type=seat_type;
        this.day=day;
        this.no_of_tickets=tickets;
        this.coupon=coupon;
        this.popcorn=popcorn;
        this.coke=coke;
        this.nachos=nachos;
    }

    void calculateBill()
    {

        /* -------- Ticket Price -------- */

        if(ticket_type.equalsIgnoreCase("Regular"))
            ticket_price=200;

        else if(ticket_type.equalsIgnoreCase("Premium"))
            ticket_price=350;

        else if(ticket_type.equalsIgnoreCase("VIP"))
            ticket_price=500;

        else
        {
            System.out.println("Invalid Ticket Type");
            return;
        }

        /* -------- Weekend Pricing -------- */

        if(day.equalsIgnoreCase("Weekend"))
        {
            ticket_price = ticket_price + (ticket_price*0.20);
        }

        /* -------- Seat Charges -------- */

        if(seat_type.equalsIgnoreCase("Normal"))
            seat_charge=0;

        else if(seat_type.equalsIgnoreCase("Balcony"))
            seat_charge=100;

        else if(seat_type.equalsIgnoreCase("Recliner"))
            seat_charge=250;

        /* -------- Ticket Subtotal -------- */

        subtotal = (ticket_price + seat_charge) * no_of_tickets;

        /* -------- Quantity Discount -------- */

        if(no_of_tickets>=5 && no_of_tickets<=8)
            discount = subtotal * 0.10;

        else if(no_of_tickets>=9 && no_of_tickets<=12)
            discount = subtotal * 0.15;

        else if(no_of_tickets>12)
            discount = subtotal * 0.20;

        subtotal = subtotal - discount;

        /* -------- Food Calculation -------- */

        food_total = (popcorn*150) + (coke*100) + (nachos*200);

        /* -------- Group Booking Offer -------- */

        if(no_of_tickets>10)
        {
            System.out.println("Group Offer: Free Popcorn for everyone!");
            food_total = food_total - (no_of_tickets*150);
            if(food_total<0)
                food_total=0;
        }

        /* -------- Coupon Discount -------- */

        if(coupon.equalsIgnoreCase("MOVIE100"))
            coupon_discount=100;

        else if(coupon.equalsIgnoreCase("MOVIE200"))
            coupon_discount=200;

        else if(coupon.equalsIgnoreCase("SUPER10"))
            coupon_discount=(subtotal+food_total)*0.10;

        /* -------- GST -------- */

        gst = (subtotal + food_total) * 0.18;

        /* -------- Final Amount -------- */

        final_amount = subtotal + food_total + gst + booking_fee - coupon_discount;
    }

    void displayBill()
    {
        System.out.println("------ MOVIE BOOKING BILL ------");

        System.out.println("Movie: "+movie);
        System.out.println("Ticket Type: "+ticket_type);
        System.out.println("Seat Type: "+seat_type);
        System.out.println("Tickets: "+no_of_tickets);

        System.out.println("Ticket Amount: "+subtotal);
        System.out.println("Food Amount: "+food_total);
        System.out.println("Discount Applied: "+discount);
        System.out.println("Coupon Discount: "+coupon_discount);
        System.out.println("GST: "+gst);
        System.out.println("Booking Fee: "+booking_fee);

        System.out.println("Final Amount: "+final_amount);
    }

    public static void main(String[] args)
    {

        Movie_Ticket_Booking_System m1 = new Movie_Ticket_Booking_System("Avengers","VIP","Recliner",
        		                         "Weekend",11,"SUPER10",5,3,2);

        m1.calculateBill();
        m1.displayBill();
    }
}